$(function () {
    $("#footer-placeholder").load("footer.html?v=3");
});